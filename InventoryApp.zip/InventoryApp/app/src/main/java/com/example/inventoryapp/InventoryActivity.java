package com.example.inventoryapp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout inventoryTable;
    private long userId;

    // I use Android's file picker to let users select a CSV file.
    private final ActivityResultLauncher<String[]> csvPicker =
            registerForActivityResult(
                    new ActivityResultContracts.OpenDocument(),
                    uri -> {
                        if (uri != null) {
                            importCsvFile(uri);
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId < 1) {
            Toast.makeText(
                    this,
                    "Please log in again",
                    Toast.LENGTH_SHORT
            ).show();
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);
        inventoryTable = findViewById(R.id.inventory_table);

        Button addButton = findViewById(R.id.button_add_item);
        Button importButton = findViewById(R.id.button_import_csv);
        Button smsButton = findViewById(R.id.button_sms_alerts);

        addButton.setOnClickListener(v -> showAddItemDialog());

        // I open the file picker when the user selects Import CSV.
        importButton.setOnClickListener(v ->
                csvPicker.launch(new String[]{
                        "text/*",
                        "application/csv",
                        "application/vnd.ms-excel",
                        "application/octet-stream"
                })
        );

        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    NotificationsActivity.class
            );

            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        loadInventory();
    }

    // I display the current user's saved inventory items.
    private void loadInventory() {

        // I keep the first row because it contains my column headings.
        if (inventoryTable.getChildCount() > 1) {
            inventoryTable.removeViews(
                    1,
                    inventoryTable.getChildCount() - 1
            );
        }

        try (Cursor cursor = databaseHelper.getInventoryItems(userId)) {

            int idColumn = cursor.getColumnIndexOrThrow("_id");
            int nameColumn = cursor.getColumnIndexOrThrow("item_name");
            int quantityColumn = cursor.getColumnIndexOrThrow("quantity");

            while (cursor.moveToNext()) {

                long itemId = cursor.getLong(idColumn);
                String itemName = cursor.getString(nameColumn);
                int quantity = cursor.getInt(quantityColumn);

                TableRow row = new TableRow(this);
                row.setPadding(0, 8, 0, 8);
                row.setGravity(Gravity.CENTER_VERTICAL);

                TextView nameText = new TextView(this);
                nameText.setText(itemName);
                nameText.setPadding(0, 8, 8, 8);
                nameText.setLayoutParams(
                        new TableRow.LayoutParams(
                                0,
                                TableRow.LayoutParams.WRAP_CONTENT,
                                2f
                        )
                );

                TextView quantityText = new TextView(this);
                quantityText.setText(String.valueOf(quantity));
                quantityText.setGravity(Gravity.CENTER);
                quantityText.setPadding(4, 8, 4, 8);
                quantityText.setLayoutParams(
                        new TableRow.LayoutParams(
                                0,
                                TableRow.LayoutParams.WRAP_CONTENT,
                                1f
                        )
                );

                // I let users tap a quantity to update it.
                quantityText.setOnClickListener(v ->
                        showUpdateQuantityDialog(
                                itemId,
                                itemName,
                                quantity
                        )
                );

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");
                deleteButton.setTextSize(12);

                deleteButton.setOnClickListener(v ->
                        confirmDelete(itemId, itemName)
                );

                row.addView(nameText);
                row.addView(quantityText);
                row.addView(deleteButton);

                inventoryTable.addView(row);
            }
        }
    }

    // I allow users to add individual items manually.
    private void showAddItemDialog() {

        LinearLayout layout = createDialogLayout();

        EditText nameInput = new EditText(this);
        nameInput.setHint("Item name");
        nameInput.setSingleLine(true);

        EditText quantityInput = new EditText(this);
        quantityInput.setHint("Quantity");
        quantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);

        layout.addView(nameInput);
        layout.addView(quantityInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Inventory Item")
                .setView(layout)
                .setPositiveButton("Add", null)
                .setNegativeButton(
                        "Cancel",
                        (d, which) -> d.dismiss()
                )
                .create();

        dialog.setOnShowListener(ignored ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(v -> {

                            String name = nameInput.getText()
                                    .toString().trim();

                            Integer quantity = parseQuantity(
                                    quantityInput.getText().toString()
                            );

                            if (name.isEmpty() || quantity == null) {
                                Toast.makeText(
                                        this,
                                        "Enter a name and valid quantity",
                                        Toast.LENGTH_SHORT
                                ).show();
                                return;
                            }

                            boolean added =
                                    databaseHelper.addInventoryItem(
                                            userId,
                                            name,
                                            quantity
                                    );

                            if (added) {
                                Toast.makeText(
                                        this,
                                        "Item added",
                                        Toast.LENGTH_SHORT
                                ).show();

                                dialog.dismiss();
                                loadInventory();

                            } else {
                                Toast.makeText(
                                        this,
                                        "Unable to add item",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        })
        );

        dialog.show();
    }

    // I allow users to change the quantity of an existing item.
    private void showUpdateQuantityDialog(
            long itemId,
            String itemName,
            int currentQuantity) {

        EditText quantityInput = new EditText(this);
        quantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        quantityInput.setText(String.valueOf(currentQuantity));
        quantityInput.setSelectAllOnFocus(true);

        LinearLayout layout = createDialogLayout();
        layout.addView(quantityInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Update " + itemName)
                .setView(layout)
                .setPositiveButton("Save", null)
                .setNegativeButton(
                        "Cancel",
                        (d, which) -> d.dismiss()
                )
                .create();

        dialog.setOnShowListener(ignored ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(v -> {

                            Integer newQuantity = parseQuantity(
                                    quantityInput.getText().toString()
                            );

                            if (newQuantity == null) {
                                Toast.makeText(
                                        this,
                                        "Enter a valid quantity",
                                        Toast.LENGTH_SHORT
                                ).show();
                                return;
                            }

                            boolean updated =
                                    databaseHelper.updateInventoryQuantity(
                                            userId,
                                            itemId,
                                            newQuantity
                                    );

                            if (updated) {

                                // I request an SMS when a positive quantity reaches zero.
                                if (currentQuantity > 0 &&
                                        newQuantity == 0) {
                                    sendLowStockAlert(itemName);
                                }

                                Toast.makeText(
                                        this,
                                        "Quantity updated",
                                        Toast.LENGTH_SHORT
                                ).show();

                                dialog.dismiss();
                                loadInventory();

                            } else {
                                Toast.makeText(
                                        this,
                                        "Unable to update quantity",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        })
        );

        dialog.show();
    }

    // I ask for confirmation before deleting an inventory item.
    private void confirmDelete(long itemId, String itemName) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Delete " + itemName + "?")
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {

                            boolean deleted =
                                    databaseHelper.deleteInventoryItem(
                                            userId,
                                            itemId
                                    );

                            if (deleted) {
                                Toast.makeText(
                                        this,
                                        "Item deleted",
                                        Toast.LENGTH_SHORT
                                ).show();

                                loadInventory();

                            } else {
                                Toast.makeText(
                                        this,
                                        "Unable to delete item",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    // I read the selected CSV file and prepare the inventory records.
    private void importCsvFile(Uri uri) {

        try {

            StringBuilder content = new StringBuilder();
            int characterCount = 0;

            // I limit the CSV size so extremely large files are rejected.
            final int maximumCharacters = 2_000_000;

            try (InputStream input =
                         getContentResolver().openInputStream(uri)) {

                if (input == null) {
                    throw new IllegalArgumentException(
                            "The selected file could not be opened"
                    );
                }

                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(
                                input,
                                StandardCharsets.UTF_8
                        ))) {

                    char[] buffer = new char[4096];
                    int length;

                    while ((length = reader.read(buffer)) != -1) {

                        characterCount += length;

                        if (characterCount > maximumCharacters) {
                            throw new IllegalArgumentException(
                                    "The CSV file is too large"
                            );
                        }

                        content.append(buffer, 0, length);
                    }
                }
            }

            List<List<String>> rows =
                    parseCsv(content.toString());

            if (rows.isEmpty()) {
                throw new IllegalArgumentException(
                        "The CSV file is empty"
                );
            }

            // I check that the CSV uses the required column headings.
            List<String> header = rows.get(0);

            if (header.size() != 2 ||
                    !header.get(0).trim()
                            .equalsIgnoreCase("Item Name") ||
                    !header.get(1).trim()
                            .equalsIgnoreCase("Quantity")) {

                throw new IllegalArgumentException(
                        "The first row must be: Item Name,Quantity"
                );
            }

            // I use a map to prevent duplicate names within one CSV import.
            Map<String, DatabaseHelper.InventoryImportItem>
                    uniqueItems = new LinkedHashMap<>();

            int invalidRows = 0;
            int validRows = 0;

            for (int i = 1; i < rows.size(); i++) {

                List<String> row = rows.get(i);

                // I skip empty lines without counting them as errors.
                if (row.size() == 1 &&
                        row.get(0).trim().isEmpty()) {
                    continue;
                }

                if (row.size() != 2) {
                    invalidRows++;
                    continue;
                }

                String itemName = row.get(0).trim();

                Integer quantity = parseQuantity(
                        row.get(1).trim()
                );

                if (itemName.isEmpty() || quantity == null) {
                    invalidRows++;
                    continue;
                }

                validRows++;

                // I keep the last quantity if the same item appears twice.
                uniqueItems.put(
                        itemName.toLowerCase(Locale.ROOT),
                        new DatabaseHelper.InventoryImportItem(
                                itemName,
                                quantity
                        )
                );
            }

            if (uniqueItems.isEmpty()) {
                Toast.makeText(
                        this,
                        "No valid inventory items found",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            List<DatabaseHelper.InventoryImportItem> items =
                    new ArrayList<>(uniqueItems.values());

            int duplicateRows = validRows - items.size();

            // I keep a final copy for use in the import confirmation listener.
            final int skippedRows = invalidRows;

            String confirmation =
                    "Items to add or update: " + items.size() +
                            "\nInvalid rows skipped: " + skippedRows +
                            "\nRepeated names in CSV: " + duplicateRows +
                            "\n\nExisting item quantities will be replaced." +
                            "\n\nContinue?";

            // I confirm the changes before saving anything to SQLite.
            new AlertDialog.Builder(this)
                    .setTitle("Import Inventory")
                    .setMessage(confirmation)
                    .setPositiveButton(
                            "Import",
                            (dialog, which) -> {

                                try {

                                    int imported =
                                            databaseHelper
                                                    .importInventoryItems(
                                                            userId,
                                                            items
                                                    );

                                    loadInventory();

                                    new AlertDialog.Builder(this)
                                            .setTitle("Import Complete")
                                            .setMessage(
                                                    imported +
                                                            " inventory items added or updated." +
                                                            "\nInvalid rows skipped: " +
                                                            skippedRows
                                            )
                                            .setPositiveButton(
                                                    "OK",
                                                    null
                                            )
                                            .show();

                                } catch (Exception e) {

                                    android.util.Log.e(
                                            "InventoryActivity",
                                            "CSV database import failed",
                                            e
                                    );

                                    Toast.makeText(
                                            this,
                                            "Unable to save imported inventory",
                                            Toast.LENGTH_LONG
                                    ).show();
                                }
                            }
                    )
                    .setNegativeButton("Cancel", null)
                    .show();

        } catch (Exception e) {

            android.util.Log.e(
                    "InventoryActivity",
                    "Unable to read CSV",
                    e
            );

            String message = e.getMessage();

            Toast.makeText(
                    this,
                    message == null
                            ? "Unable to read CSV file"
                            : message,
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // I read standard CSV fields, including quoted names containing commas.
    private List<List<String>> parseCsv(String csv) {

        List<List<String>> rows = new ArrayList<>();
        List<String> currentRow = new ArrayList<>();
        StringBuilder field = new StringBuilder();

        boolean inQuotes = false;
        boolean afterQuote = false;
        boolean atFieldStart = true;

        for (int i = 0; i < csv.length(); i++) {

            char character = csv.charAt(i);

            // I ignore a UTF-8 byte order mark at the beginning of the file.
            if (i == 0 && character == '\uFEFF') {
                continue;
            }

            if (inQuotes) {

                if (character == '"') {

                    if (i + 1 < csv.length() &&
                            csv.charAt(i + 1) == '"') {

                        field.append('"');
                        i++;

                    } else {
                        inQuotes = false;
                        afterQuote = true;
                    }

                } else {
                    field.append(character);
                }

            } else if (afterQuote) {

                if (character == ',') {

                    currentRow.add(field.toString());
                    field.setLength(0);
                    afterQuote = false;
                    atFieldStart = true;

                } else if (character == '\n' ||
                        character == '\r') {

                    currentRow.add(field.toString());
                    rows.add(currentRow);

                    currentRow = new ArrayList<>();
                    field.setLength(0);
                    afterQuote = false;
                    atFieldStart = true;

                    if (character == '\r' &&
                            i + 1 < csv.length() &&
                            csv.charAt(i + 1) == '\n') {
                        i++;
                    }

                } else if (character != ' ' &&
                        character != '\t') {

                    throw new IllegalArgumentException(
                            "Invalid text after a quoted CSV value"
                    );
                }

            } else if (character == '"' && atFieldStart) {

                inQuotes = true;
                atFieldStart = false;

            } else if (character == '"') {

                throw new IllegalArgumentException(
                        "Unexpected quote in CSV file"
                );

            } else if (character == ',') {

                currentRow.add(field.toString());
                field.setLength(0);
                atFieldStart = true;

            } else if (character == '\n' ||
                    character == '\r') {

                currentRow.add(field.toString());
                rows.add(currentRow);

                currentRow = new ArrayList<>();
                field.setLength(0);
                atFieldStart = true;

                if (character == '\r' &&
                        i + 1 < csv.length() &&
                        csv.charAt(i + 1) == '\n') {
                    i++;
                }

            } else {

                field.append(character);

                // I allow spaces before an unquoted value.
                if (character != ' ' &&
                        character != '\t') {
                    atFieldStart = false;
                }
            }
        }

        if (inQuotes) {
            throw new IllegalArgumentException(
                    "The CSV file contains an unfinished quoted value"
            );
        }

        if (field.length() > 0 ||
                !currentRow.isEmpty() ||
                afterQuote) {

            currentRow.add(field.toString());
            rows.add(currentRow);
        }

        return rows;
    }

    // I accept nonnegative whole numbers as inventory quantities.
    private Integer parseQuantity(String value) {

        try {

            int quantity = Integer.parseInt(value.trim());

            return quantity >= 0 ? quantity : null;

        } catch (NumberFormatException e) {
            return null;
        }
    }

    // I use consistent spacing for my input dialogs.
    private LinearLayout createDialogLayout() {

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        int padding = (int) (
                24 * getResources()
                        .getDisplayMetrics()
                        .density
        );

        layout.setPadding(padding, 12, padding, 0);

        return layout;
    }

    // I request an SMS alert when a manually updated quantity reaches zero.
    private void sendLowStockAlert(String itemName) {

        SharedPreferences preferences =
                getSharedPreferences(
                        "inventory_alert_settings",
                        MODE_PRIVATE
                );

        boolean alertsEnabled = preferences.getBoolean(
                "sms_enabled_" + userId,
                false
        );

        String phoneNumber = preferences.getString(
                "phone_" + userId,
                ""
        );

        if (!alertsEnabled || phoneNumber.isEmpty()) {
            return;
        }

        // I keep inventory management available when SMS permission is denied.
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "SMS permission is not available. Inventory was still updated.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        String message =
                "Inventory Alert: " + itemName +
                        " is out of stock. Current quantity: 0.";

        try {

            SmsManager smsManager =
                    getSystemService(SmsManager.class);

            if (smsManager == null) {
                Toast.makeText(
                        this,
                        "SMS is not supported on this device",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "SMS alert submitted for sending",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            android.util.Log.e(
                    "InventoryActivity",
                    "Unable to send SMS alert",
                    e
            );

            Toast.makeText(
                    this,
                    "Unable to send SMS. Inventory was still updated.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
