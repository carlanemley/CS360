package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.List;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    // I use these values to identify my SQLite database.
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // I store user accounts and protected passwords in this table.
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash TEXT NOT NULL)"
        );

        // I link inventory records to the user who created them.
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "item_name TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL DEFAULT 0 " +
                        "CHECK(quantity >= 0), " +
                        "FOREIGN KEY(user_id) REFERENCES users(id))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // I will add database migrations here if the structure changes.
    }

    // I protect account passwords using a random salt and a password hash.
    private String hashPassword(String password) throws Exception {

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        KeySpec spec = new PBEKeySpec(
                password.toCharArray(), salt, 120000, 256);

        SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

        byte[] hash = factory.generateSecret(spec).getEncoded();

        return Base64.getEncoder().encodeToString(salt) + ":" +
                Base64.getEncoder().encodeToString(hash);
    }

    // I verify the entered password without storing it as readable text.
    private boolean verifyPassword(String password, String stored)
            throws Exception {

        String[] parts = stored.split(":");

        if (parts.length != 2) {
            return false;
        }

        byte[] salt = Base64.getDecoder().decode(parts[0]);
        byte[] savedHash = Base64.getDecoder().decode(parts[1]);

        KeySpec spec = new PBEKeySpec(
                password.toCharArray(), salt, 120000, 256);

        SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

        byte[] attemptedHash = factory.generateSecret(spec).getEncoded();

        return MessageDigest.isEqual(savedHash, attemptedHash);
    }

    // I register new accounts in my SQLite database.
    public boolean registerUser(String username, String password) {

        if (username == null || username.trim().isEmpty() ||
                password == null || password.length() < 8) {
            return false;
        }

        try {
            SQLiteDatabase db = getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("username", username.trim());
            values.put("password_hash", hashPassword(password));

            return db.insert("users", null, values) != -1;

        } catch (Exception e) {
            Log.e("DatabaseHelper", "Account registration failed", e);
            return false;
        }
    }

    // I check login credentials and return the matching user's ID.
    public long loginUser(String username, String password) {

        if (username == null || password == null) {
            return -1;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                "users",
                new String[]{"id", "password_hash"},
                "username = ?",
                new String[]{username.trim()},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                long userId = cursor.getLong(0);
                String storedHash = cursor.getString(1);

                if (verifyPassword(password, storedHash)) {
                    return userId;
                }
            }

        } catch (Exception e) {
            Log.e("DatabaseHelper", "Login verification failed", e);
        }

        return -1;
    }

    // I add individual inventory items under the signed-in user's account.
    public boolean addInventoryItem(long userId, String itemName, int quantity) {

        if (userId < 1 || itemName == null ||
                itemName.trim().isEmpty() || quantity < 0) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);

        return db.insert("inventory", null, values) != -1;
    }

    // I retrieve only the inventory records belonging to the current user.
    public Cursor getInventoryItems(long userId) {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                "inventory",
                new String[]{"id AS _id", "item_name", "quantity"},
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null, null,
                "item_name ASC"
        );
    }

    // I allow users to change the quantity of an existing item.
    public boolean updateInventoryQuantity(
            long userId, long itemId, int quantity) {

        if (userId < 1 || itemId < 1 || quantity < 0) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("quantity", quantity);

        int rowsUpdated = db.update(
                "inventory",
                values,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(itemId),
                        String.valueOf(userId)
                }
        );

        return rowsUpdated > 0;
    }

    // I remove only inventory items belonging to the current user.
    public boolean deleteInventoryItem(long userId, long itemId) {

        if (userId < 1 || itemId < 1) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                "inventory",
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(itemId),
                        String.valueOf(userId)
                }
        );

        return rowsDeleted > 0;
    }

    // I use this class to hold an item and its quantity during CSV import.
    public static class InventoryImportItem {

        public final String name;
        public final int quantity;

        public InventoryImportItem(String name, int quantity) {
            this.name = name;
            this.quantity = quantity;
        }
    }

    // I import several items together and update existing matching names.
    public int importInventoryItems(
            long userId, List<InventoryImportItem> items) {

        if (userId < 1 || items == null) {
            return 0;
        }

        SQLiteDatabase db = getWritableDatabase();
        int importedCount = 0;

        // I use a transaction so a database error will not leave a partial import.
        db.beginTransaction();

        try {

            for (InventoryImportItem item : items) {

                if (item == null || item.name == null ||
                        item.name.trim().isEmpty() ||
                        item.quantity < 0) {
                    continue;
                }

                String itemName = item.name.trim();
                long existingId = -1;

                // I look for an existing item with the same name.
                try (Cursor cursor = db.query(
                        "inventory",
                        new String[]{"id"},
                        "user_id = ? AND item_name = ? COLLATE NOCASE",
                        new String[]{
                                String.valueOf(userId),
                                itemName
                        },
                        null, null, "id ASC", "1")) {

                    if (cursor.moveToFirst()) {
                        existingId = cursor.getLong(0);
                    }
                }

                ContentValues values = new ContentValues();
                values.put("quantity", item.quantity);

                if (existingId != -1) {

                    // I update the quantity instead of creating a duplicate.
                    db.update(
                            "inventory",
                            values,
                            "id = ? AND user_id = ?",
                            new String[]{
                                    String.valueOf(existingId),
                                    String.valueOf(userId)
                            }
                    );

                } else {

                    // I create a new record when the item is not already saved.
                    values.put("user_id", userId);
                    values.put("item_name", itemName);

                    long result = db.insertOrThrow(
                            "inventory", null, values);

                    if (result == -1) {
                        throw new IllegalStateException(
                                "Unable to insert inventory item");
                    }
                }

                importedCount++;
            }

            db.setTransactionSuccessful();

        } finally {
            db.endTransaction();
        }

        return importedCount;
    }
}
