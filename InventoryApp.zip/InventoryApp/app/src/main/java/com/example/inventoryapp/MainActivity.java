
package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // I use these variables to access the username and password fields.
    private EditText usernameText;
    private EditText passwordText;

    // I use DatabaseHelper to save accounts and check login information.
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // I connected my Java variables to the fields and buttons on the login screen.
        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);

        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);

        // I initialize my SQLite database so account information can be saved.
        databaseHelper = new DatabaseHelper(this);

        // I use this button to create a new account with a username and password.
        createAccountButton.setOnClickListener(v -> {

            String username = usernameText.getText().toString().trim();
            String password = passwordText.getText().toString();

            // I check that both fields have information before creating an account.
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // I require at least eight characters to make passwords more secure.
            if (password.length() < 8) {
                Toast.makeText(this,
                        "Password must contain at least 8 characters",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // I save the new account in the SQLite database.
            boolean created = databaseHelper.registerUser(username, password);

            if (created) {
                Toast.makeText(this,
                        "Account created! You can now log in.",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "Unable to create account. Username may already exist.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // I use this button to check whether the entered login information is correct.
        loginButton.setOnClickListener(v -> {

            String username = usernameText.getText().toString().trim();
            String password = passwordText.getText().toString();

            // I make sure the user entered both a username and password.
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter your username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // I check the saved account information and retrieve the user's ID.
            long userId = databaseHelper.loginUser(username, password);

            if (userId != -1) {

                Toast.makeText(this,
                        "Login successful!",
                        Toast.LENGTH_SHORT).show();

                // I open the inventory screen when the login information is correct.
                Intent intent = new Intent(
                        MainActivity.this,
                        InventoryActivity.class
                );

                // I pass the user's ID so the inventory can be linked to their account.
                intent.putExtra("USER_ID", userId);

                startActivity(intent);

                // I close the login screen after opening the inventory screen.
                finish();

            } else {

                // I display an error message when the login information is incorrect.
                Toast.makeText(this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
