package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class NotificationsActivity extends AppCompatActivity {

    private EditText phoneNumberInput;
    private SharedPreferences preferences;
    private long userId;

    // I use this launcher to request SMS permission and check the user's choice.
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {

                        if (isGranted) {
                            saveAlertSettings();
                        } else {
                            // I keep the inventory features available if SMS permission is denied.
                            Toast.makeText(this,
                                    "SMS permission denied. Inventory will still work.",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // I identify the signed-in user so alert settings stay separate.
        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId < 1) {
            finish();
            return;
        }

        // I connect the phone number field and buttons to my Java code.
        phoneNumberInput = findViewById(R.id.phoneNumberInput);

        Button enableButton = findViewById(R.id.enablesmsbutton);
        Button notNowButton = findViewById(R.id.notnowbutton);

        // I save notification preferences locally for each account.
        preferences = getSharedPreferences(
                "inventory_alert_settings",
                MODE_PRIVATE
        );

        phoneNumberInput.setText(
                preferences.getString("phone_" + userId, "")
        );

        // I check the phone number before requesting SMS permission.
        enableButton.setOnClickListener(v -> {

            String phoneNumber = phoneNumberInput.getText()
                    .toString().trim();

            if (!phoneNumber.matches("\\+?[0-9]{10,15}")) {
                Toast.makeText(this,
                        "Enter a valid phone number using digits only",
                        Toast.LENGTH_LONG).show();
                return;
            }

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED) {

                saveAlertSettings();

            } else {

                // I ask for SMS permission only when the user enables alerts.
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        // I allow users to leave without enabling SMS alerts.
        notNowButton.setOnClickListener(v -> finish());
    }

    // I save the selected phone number after SMS permission is granted.
    private void saveAlertSettings() {

        String phoneNumber = phoneNumberInput.getText()
                .toString().trim();

        if (!phoneNumber.matches("\\+?[0-9]{10,15}")) {
            Toast.makeText(this,
                    "Enter a valid phone number",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        preferences.edit()
                .putString("phone_" + userId, phoneNumber)
                .putBoolean("sms_enabled_" + userId, true)
                .apply();

        Toast.makeText(this,
                "SMS alerts enabled",
                Toast.LENGTH_SHORT).show();

        finish();
    }
}
